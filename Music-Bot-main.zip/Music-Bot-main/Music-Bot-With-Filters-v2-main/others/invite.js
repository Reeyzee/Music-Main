const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "invite",
  aliases: ["inv"],
  description: "Invite the bot to your server.",
  execute(message) {

    let inviteEmbed = new MessageEmbed()
      .setTitle("Add us to your server!")
      .setDescription("Love using ? Great, Thank you! Consider adding it to your server")
      .setColor("#F0EAD6")
      .setAuthor('Rampage','https://media.discordapp.net/attachments/837796887117430834/837796954146471956/rampage.gif')
      .setThumbnail(message.guild.iconURL())
      .addField(`Use the following link to add Rampage to your discord server`, '', true)

    inviteEmbed.setTimestamp();

    return message.channel.send(inviteEmbed).catch(console.error);
  }
};